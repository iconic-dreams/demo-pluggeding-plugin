# demo-pluggeding-plugin
Minimal Pluggeding System Demonstration
