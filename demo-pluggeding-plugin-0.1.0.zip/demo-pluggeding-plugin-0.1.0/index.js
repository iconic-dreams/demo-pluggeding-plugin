/**
 * @license The MIT License (MIT)             - [https://github.com/iconic-dreams/demo-pluggeding-plugin/blob/master/LICENSE]
 * @copyright Copyright (c) 2019 Lauro Moraes - [https://github.com/subversivo58]
 * @version 0.1.0 [development stage]         - [https://github.com/iconic-dreams/demo-pluggeding-plugin/blob/master/VERSIONING.md]
 */
 
 // remove loader icon
 $('#plugin-loader-icon').remove()
 
 // simple add `<h2>` to `<body>`
 $('#body').append('<h2>Hello World</h2>')
